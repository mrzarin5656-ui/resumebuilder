# Resume Builder - Design Guidelines

## Design Approach
**System-Based Approach**: Drawing from Notion's clean forms and Linear's crisp typography, combined with Material Design principles for structured data input. This utility-focused application prioritizes clarity, usability, and professional output over decorative elements.

## Core Design Principles
- **Functional Clarity**: Every element serves the resume creation workflow
- **Professional Output**: Preview mimics industry-standard resume aesthetics
- **Seamless Real-time**: Zero lag between input and preview update
- **Guided Experience**: Clear visual hierarchy guides users through sections

## Layout System

### Desktop Layout (1024px+)
Two-column split layout:
- **Left Panel (45%)**: Form inputs with scrollable content
- **Right Panel (55%)**: Fixed/sticky resume preview in A4 aspect ratio
- Container: `max-w-7xl mx-auto px-6`

### Tablet/Mobile (< 1024px)
Stacked single-column:
- Form section first
- Sticky "Preview Resume" button to toggle preview overlay
- Preview slides up from bottom as modal overlay

### Spacing System
Use Tailwind units: **2, 4, 6, 8, 12, 16** for consistent rhythm
- Section gaps: `gap-8`
- Input field spacing: `space-y-4`
- Panel padding: `p-6` mobile, `p-8` desktop

## Typography

### Form Interface Fonts
- **Primary**: Inter or DM Sans (Google Fonts)
- Section headers: `text-xl font-semibold` (20px)
- Input labels: `text-sm font-medium text-gray-700` (14px)
- Helper text: `text-xs text-gray-500` (12px)

### Resume Preview Fonts
- **Professional Font**: Crimson Text or Lora for name/headers
- **Body Font**: Inter or Source Sans Pro
- Applicant name: `text-4xl font-bold` (36px)
- Job title: `text-xl text-gray-600` (20px)
- Section headings: `text-lg font-semibold uppercase tracking-wide` (18px)
- Body text: `text-sm leading-relaxed` (14px)

## Component Library

### Form Section Components

**Personal Info Card**
- Full-width name input (prominent)
- Two-column grid for email/phone
- Single-column for job title and summary
- All inputs with subtle borders: `border border-gray-300 focus:border-blue-500`

**Dynamic List Sections** (Skills, Education, Experience)
- Card-based containers with `bg-white border rounded-lg p-6`
- "+ Add [Section]" button with icon: `border-2 border-dashed border-gray-300 hover:border-blue-400`
- Each entry as removable card with subtle hover state
- Trash icon button aligned top-right of each entry

**Skills Section**
- Tag-style pill inputs or comma-separated text field
- Visual: `inline-flex items-center px-3 py-1 rounded-full bg-blue-50 text-blue-700`

**Education/Experience Entries**
- Institution/Company: Large text input
- Degree/Position: Medium text input
- Date range: Two small inputs (Start - End) in row
- Description: Textarea with `rows="3"`
- Delete button: Ghost button with trash icon

### Resume Preview Components

**Header Section**
- Name: Bold, large, centered or left-aligned
- Contact row: Email • Phone • Location (subtle separator dots)
- Professional summary: Italicized, 2-3 lines max

**Content Sections**
- Section dividers: Horizontal line `border-t-2 border-gray-800`
- Skills: Grid layout or comma-separated inline
- Education/Experience: Chronological list with institution bold, dates right-aligned
- Bullet points for descriptions using proper `<ul>` styling

**Preview Container Styling**
- White background with subtle shadow: `bg-white shadow-lg`
- A4 proportions: `aspect-[1/1.414]` or fixed `max-h-[1122px]`
- Inner padding representing paper margins: `p-12`
- Print-ready appearance with proper spacing

### Action Bar
- Sticky bottom on mobile, top-right on desktop
- Primary "Download PDF" button: `bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium`
- Optional "Clear Form" secondary button

## Interaction Patterns

**Real-time Preview Updates**
- Debounced input (150ms) to prevent render lag
- Smooth content transitions, no jarring jumps
- Empty state messaging in preview: "Start typing to see your resume..."

**Form Validation**
- Inline validation on blur
- Required field indicators: Red asterisk
- Error states: `border-red-500` with small error message below

**Add/Remove Entries**
- Fade-in animation for new entries (200ms)
- Confirm dialog for delete actions on filled entries
- Smooth height transitions

## Images
**No hero images required**. This is a tool-focused application where functionality takes precedence. The interface should be clean and distraction-free.

## Accessibility
- Semantic HTML for form structure
- Proper label associations for all inputs
- Keyboard navigation for add/remove actions
- ARIA labels for icon-only buttons
- Focus indicators on all interactive elements: `focus:ring-2 focus:ring-blue-500`

## Mobile Optimization
- Touch-friendly targets (min 44px height)
- Simplified preview toggle instead of split view
- Single-column form layout
- Collapsible sections with accordions for long forms