import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Download, Eye, FileText } from "lucide-react";
import PersonalInfoForm from "@/components/PersonalInfoForm";
import SkillsForm from "@/components/SkillsForm";
import EducationForm from "@/components/EducationForm";
import ExperienceForm from "@/components/ExperienceForm";
import ThemeCustomizer from "@/components/ThemeCustomizer";
import ResumePreview from "@/components/ResumePreview";
import { generatePDF } from "@/lib/pdfGenerator";
import type { ResumeData, Education, Experience, ColorTheme } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function Home() {
  const [showPreview, setShowPreview] = useState(false);
  const [resumeData, setResumeData] = useState<ResumeData>({
    fullName: "",
    jobTitle: "",
    email: "",
    phone: "",
    location: "",
    summary: "",
    skills: [],
    education: [],
    experience: [],
    theme: {
      accentColor: "#3b82f6",
      headerStyle: "line",
    },
  });

  const handleFieldChange = (field: string, value: string) => {
    setResumeData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSkillsChange = (skills: string[]) => {
    setResumeData((prev) => ({ ...prev, skills }));
  };

  const handleEducationChange = (education: Education[]) => {
    setResumeData((prev) => ({ ...prev, education }));
  };

  const handleExperienceChange = (experience: Experience[]) => {
    setResumeData((prev) => ({ ...prev, experience }));
  };

  const handleThemeChange = (theme: ColorTheme) => {
    setResumeData((prev) => ({ ...prev, theme }));
  };

  const handleDownloadPDF = () => {
    generatePDF(resumeData);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-semibold">Resume Builder</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="lg:hidden gap-2"
                onClick={() => setShowPreview(true)}
                data-testid="button-show-preview"
              >
                <Eye className="h-4 w-4" />
                Preview
              </Button>
              <Button
                onClick={handleDownloadPDF}
                data-testid="button-download-pdf"
                className="gap-2"
              >
                <Download className="h-4 w-4" />
                Download PDF
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-[45%_55%] gap-8">
          <ScrollArea className="h-[calc(100vh-140px)]">
            <div className="space-y-8 pr-4">
              <PersonalInfoForm
                fullName={resumeData.fullName}
                jobTitle={resumeData.jobTitle}
                email={resumeData.email}
                phone={resumeData.phone}
                location={resumeData.location}
                summary={resumeData.summary}
                onFieldChange={handleFieldChange}
              />

              <ThemeCustomizer
                theme={resumeData.theme}
                onThemeChange={handleThemeChange}
              />

              <SkillsForm
                skills={resumeData.skills}
                onSkillsChange={handleSkillsChange}
              />

              <ExperienceForm
                experience={resumeData.experience}
                onExperienceChange={handleExperienceChange}
              />

              <EducationForm
                education={resumeData.education}
                onEducationChange={handleEducationChange}
              />
            </div>
          </ScrollArea>

          <div className="hidden lg:block sticky top-[100px] h-[calc(100vh-140px)]">
            <div className="h-full rounded-md border border-border overflow-hidden">
              <ScrollArea className="h-full">
                <ResumePreview data={resumeData} />
              </ScrollArea>
            </div>
          </div>
        </div>
      </div>

      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-3xl max-h-[90vh] p-0">
          <DialogHeader className="px-6 pt-6 pb-4 border-b">
            <DialogTitle>Resume Preview</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[70vh]">
            <ResumePreview data={resumeData} />
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
