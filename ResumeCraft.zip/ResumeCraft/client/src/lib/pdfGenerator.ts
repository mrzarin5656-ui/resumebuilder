import jsPDF from "jspdf";
import type { ResumeData } from "@shared/schema";

function hexToRgb(hex: string): [number, number, number] {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? [
        parseInt(result[1], 16),
        parseInt(result[2], 16),
        parseInt(result[3], 16),
      ]
    : [59, 130, 246];
}

export function generatePDF(data: ResumeData) {
  const pdf = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = pdf.internal.pageSize.getWidth();
  const margin = 20;
  const contentWidth = pageWidth - 2 * margin;
  let yPosition = margin;
  const lineHeight = 7;
  const accentRgb = hexToRgb(data.theme.accentColor);

  if (data.theme.headerStyle === "filled") {
    pdf.setFillColor(...accentRgb);
    pdf.rect(0, 0, pageWidth, 40, "F");
    pdf.setTextColor(255, 255, 255);
  } else {
    pdf.setTextColor(...accentRgb);
  }

  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(24);
  if (data.fullName) {
    pdf.text(data.fullName, margin, yPosition + 10);
  }

  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(14);
  if (data.jobTitle) {
    if (data.theme.headerStyle === "filled") {
      pdf.setTextColor(255, 255, 255);
    } else {
      pdf.setTextColor(100, 100, 100);
    }
    pdf.text(data.jobTitle, margin, yPosition + 18);
  }

  yPosition = data.theme.headerStyle === "filled" ? 45 : 30;
  pdf.setTextColor(0, 0, 0);

  pdf.setFontSize(10);
  const contactInfo = [data.email, data.phone, data.location]
    .filter(Boolean)
    .join(" • ");
  if (contactInfo) {
    pdf.text(contactInfo, margin, yPosition);
    yPosition += 8;
  }

  if (data.theme.headerStyle === "line") {
    pdf.setDrawColor(...accentRgb);
    pdf.setLineWidth(1);
  } else {
    pdf.setDrawColor(0, 0, 0);
    pdf.setLineWidth(0.5);
  }
  
  if (data.theme.headerStyle !== "filled") {
    pdf.line(margin, yPosition, pageWidth - margin, yPosition);
    yPosition += 8;
  }

  const addSectionHeader = (title: string) => {
    if (data.theme.headerStyle === "filled") {
      pdf.setFillColor(...accentRgb);
      pdf.rect(margin - 3, yPosition - 5, contentWidth + 6, 8, "F");
      pdf.setTextColor(255, 255, 255);
    } else if (data.theme.headerStyle === "line") {
      pdf.setTextColor(...accentRgb);
    } else {
      pdf.setTextColor(...accentRgb);
    }

    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(12);
    pdf.text(title, margin, yPosition);
    yPosition += lineHeight;

    if (data.theme.headerStyle === "line") {
      pdf.setDrawColor(...accentRgb);
      pdf.setLineWidth(0.8);
      pdf.line(margin, yPosition - 5, pageWidth - margin, yPosition - 5);
    }

    pdf.setTextColor(0, 0, 0);
  };

  if (data.summary) {
    addSectionHeader("PROFESSIONAL SUMMARY");

    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(10);
    const summaryLines = pdf.splitTextToSize(data.summary, contentWidth);
    pdf.text(summaryLines, margin, yPosition);
    yPosition += summaryLines.length * lineHeight + 5;
  }

  if (data.skills.length > 0) {
    addSectionHeader("SKILLS");

    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(10);
    const skillsText = data.skills.join(" • ");
    const skillsLines = pdf.splitTextToSize(skillsText, contentWidth);
    pdf.text(skillsLines, margin, yPosition);
    yPosition += skillsLines.length * lineHeight + 5;
  }

  if (data.experience.length > 0) {
    addSectionHeader("WORK EXPERIENCE");

    data.experience.forEach((exp) => {
      if (yPosition > 250) {
        pdf.addPage();
        yPosition = margin;
      }

      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(10);
      if (exp.position) {
        pdf.text(exp.position, margin, yPosition);
      }

      if (exp.startDate || exp.endDate) {
        const dateText = [exp.startDate, exp.endDate].filter(Boolean).join(" - ");
        pdf.text(dateText, pageWidth - margin, yPosition, { align: "right" });
      }
      yPosition += lineHeight;

      pdf.setFont("helvetica", "normal");
      pdf.setTextColor(100, 100, 100);
      if (exp.company) {
        pdf.text(exp.company, margin, yPosition);
        yPosition += lineHeight;
      }

      pdf.setTextColor(0, 0, 0);
      if (exp.description) {
        const descLines = pdf.splitTextToSize(exp.description, contentWidth);
        pdf.text(descLines, margin, yPosition);
        yPosition += descLines.length * lineHeight + 3;
      }

      yPosition += 2;
    });
  }

  if (data.education.length > 0) {
    if (yPosition > 220) {
      pdf.addPage();
      yPosition = margin;
    }

    addSectionHeader("EDUCATION");

    data.education.forEach((edu) => {
      if (yPosition > 250) {
        pdf.addPage();
        yPosition = margin;
      }

      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(10);
      if (edu.degree) {
        pdf.text(edu.degree, margin, yPosition);
      }

      if (edu.startDate || edu.endDate) {
        const dateText = [edu.startDate, edu.endDate].filter(Boolean).join(" - ");
        pdf.text(dateText, pageWidth - margin, yPosition, { align: "right" });
      }
      yPosition += lineHeight;

      pdf.setFont("helvetica", "normal");
      pdf.setTextColor(100, 100, 100);
      if (edu.institution) {
        pdf.text(edu.institution, margin, yPosition);
        yPosition += lineHeight;
      }

      pdf.setTextColor(0, 0, 0);
      if (edu.description) {
        const descLines = pdf.splitTextToSize(edu.description, contentWidth);
        pdf.text(descLines, margin, yPosition);
        yPosition += descLines.length * lineHeight + 3;
      }

      yPosition += 2;
    });
  }

  pdf.save(`${data.fullName || "resume"}.pdf`);
}
