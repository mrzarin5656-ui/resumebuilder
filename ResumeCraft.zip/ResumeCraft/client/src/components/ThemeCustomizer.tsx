import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import type { ColorTheme } from "@shared/schema";

interface ThemeCustomizerProps {
  theme: ColorTheme;
  onThemeChange: (theme: ColorTheme) => void;
}

const colorOptions = [
  { name: "Blue", value: "#3b82f6", bg: "bg-blue-500" },
  { name: "Indigo", value: "#6366f1", bg: "bg-indigo-500" },
  { name: "Purple", value: "#a855f7", bg: "bg-purple-500" },
  { name: "Green", value: "#10b981", bg: "bg-green-500" },
  { name: "Teal", value: "#14b8a6", bg: "bg-teal-500" },
  { name: "Red", value: "#ef4444", bg: "bg-red-500" },
  { name: "Orange", value: "#f97316", bg: "bg-orange-500" },
  { name: "Gray", value: "#6b7280", bg: "bg-gray-500" },
];

const headerStyles = [
  { name: "Bold", value: "bold" as const, description: "Strong header with bold name" },
  { name: "Line", value: "line" as const, description: "Underlined header style" },
  { name: "Filled", value: "filled" as const, description: "Filled background header" },
];

export default function ThemeCustomizer({ theme, onThemeChange }: ThemeCustomizerProps) {
  const handleColorChange = (color: string) => {
    onThemeChange({ ...theme, accentColor: color });
  };

  const handleHeaderStyleChange = (style: "bold" | "line" | "filled") => {
    onThemeChange({ ...theme, headerStyle: style });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-4">Theme Customization</h2>
        
        <div className="space-y-6">
          <div>
            <Label className="text-sm font-medium mb-3 block">Accent Color</Label>
            <div className="grid grid-cols-4 gap-3">
              {colorOptions.map((color) => (
                <button
                  key={color.value}
                  onClick={() => handleColorChange(color.value)}
                  data-testid={`button-color-${color.name.toLowerCase()}`}
                  className={`flex flex-col items-center gap-2 p-3 rounded-md border-2 hover-elevate active-elevate-2 ${
                    theme.accentColor === color.value
                      ? "border-primary"
                      : "border-border"
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full ${color.bg}`} />
                  <span className="text-xs font-medium">{color.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium mb-3 block">Header Style</Label>
            <RadioGroup
              value={theme.headerStyle}
              onValueChange={(value) => handleHeaderStyleChange(value as "bold" | "line" | "filled")}
            >
              <div className="space-y-3">
                {headerStyles.map((style) => (
                  <div
                    key={style.value}
                    className="flex items-start space-x-3 p-3 rounded-md border hover-elevate active-elevate-2"
                  >
                    <RadioGroupItem
                      value={style.value}
                      id={`style-${style.value}`}
                      data-testid={`radio-style-${style.value}`}
                      className="mt-0.5"
                    />
                    <div className="flex-1">
                      <Label
                        htmlFor={`style-${style.value}`}
                        className="text-sm font-medium cursor-pointer"
                      >
                        {style.name}
                      </Label>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {style.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </div>
        </div>
      </div>
    </div>
  );
}
