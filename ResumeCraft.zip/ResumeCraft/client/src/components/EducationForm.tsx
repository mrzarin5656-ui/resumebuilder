import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plus, Trash2 } from "lucide-react";
import type { Education } from "@shared/schema";

interface EducationFormProps {
  education: Education[];
  onEducationChange: (education: Education[]) => void;
}

export default function EducationForm({
  education,
  onEducationChange,
}: EducationFormProps) {
  const handleAddEducation = () => {
    const newEducation: Education = {
      id: Date.now().toString(),
      institution: "",
      degree: "",
      startDate: "",
      endDate: "",
      description: "",
    };
    onEducationChange([...education, newEducation]);
  };

  const handleRemoveEducation = (id: string) => {
    onEducationChange(education.filter((edu) => edu.id !== id));
  };

  const handleFieldChange = (id: string, field: keyof Education, value: string) => {
    onEducationChange(
      education.map((edu) =>
        edu.id === id ? { ...edu, [field]: value } : edu
      )
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Education</h2>
        <Button
          type="button"
          variant="outline"
          size="sm"
          data-testid="button-add-education"
          onClick={handleAddEducation}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Education
        </Button>
      </div>

      <div className="space-y-4">
        {education.map((edu, index) => (
          <Card key={edu.id} className="p-6" data-testid={`card-education-${index}`}>
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 space-y-4">
                  <div>
                    <Label htmlFor={`institution-${edu.id}`} className="text-sm font-medium">
                      Institution
                    </Label>
                    <Input
                      id={`institution-${edu.id}`}
                      data-testid={`input-institution-${index}`}
                      placeholder="University Name"
                      value={edu.institution}
                      onChange={(e) =>
                        handleFieldChange(edu.id, "institution", e.target.value)
                      }
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor={`degree-${edu.id}`} className="text-sm font-medium">
                      Degree
                    </Label>
                    <Input
                      id={`degree-${edu.id}`}
                      data-testid={`input-degree-${index}`}
                      placeholder="Bachelor of Science in Computer Science"
                      value={edu.degree}
                      onChange={(e) =>
                        handleFieldChange(edu.id, "degree", e.target.value)
                      }
                      className="mt-1"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor={`startDate-${edu.id}`} className="text-sm font-medium">
                        Start Date
                      </Label>
                      <Input
                        id={`startDate-${edu.id}`}
                        data-testid={`input-start-date-${index}`}
                        placeholder="Sep 2018"
                        value={edu.startDate}
                        onChange={(e) =>
                          handleFieldChange(edu.id, "startDate", e.target.value)
                        }
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor={`endDate-${edu.id}`} className="text-sm font-medium">
                        End Date
                      </Label>
                      <Input
                        id={`endDate-${edu.id}`}
                        data-testid={`input-end-date-${index}`}
                        placeholder="May 2022"
                        value={edu.endDate}
                        onChange={(e) =>
                          handleFieldChange(edu.id, "endDate", e.target.value)
                        }
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor={`description-${edu.id}`} className="text-sm font-medium">
                      Description
                    </Label>
                    <Textarea
                      id={`description-${edu.id}`}
                      data-testid={`input-description-${index}`}
                      placeholder="Key achievements, relevant coursework, honors..."
                      value={edu.description}
                      onChange={(e) =>
                        handleFieldChange(edu.id, "description", e.target.value)
                      }
                      rows={3}
                      className="mt-1 resize-none"
                    />
                  </div>
                </div>

                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  data-testid={`button-remove-education-${index}`}
                  onClick={() => handleRemoveEducation(edu.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}

        {education.length === 0 && (
          <button
            type="button"
            onClick={handleAddEducation}
            data-testid="button-add-first-education"
            className="w-full border-2 border-dashed border-border rounded-md p-8 text-center hover-elevate active-elevate-2"
          >
            <Plus className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
            <p className="text-sm font-medium text-muted-foreground">
              Add your first education entry
            </p>
          </button>
        )}
      </div>
    </div>
  );
}
