import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { X, Plus } from "lucide-react";
import { useState } from "react";

interface SkillsFormProps {
  skills: string[];
  onSkillsChange: (skills: string[]) => void;
}

export default function SkillsForm({ skills, onSkillsChange }: SkillsFormProps) {
  const [inputValue, setInputValue] = useState("");

  const handleAddSkill = () => {
    if (inputValue.trim() && !skills.includes(inputValue.trim())) {
      onSkillsChange([...skills, inputValue.trim()]);
      setInputValue("");
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    onSkillsChange(skills.filter((skill) => skill !== skillToRemove));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddSkill();
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Skills</h2>

      <div>
        <Label htmlFor="skillInput" className="text-sm font-medium">
          Add Skills
        </Label>
        <div className="flex gap-2 mt-1">
          <Input
            id="skillInput"
            data-testid="input-skill"
            placeholder="e.g., JavaScript, React, Node.js"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
          />
          <Button
            type="button"
            size="icon"
            data-testid="button-add-skill"
            onClick={handleAddSkill}
            disabled={!inputValue.trim()}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {skills.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {skills.map((skill, index) => (
            <Badge
              key={index}
              variant="secondary"
              className="gap-1 pr-1"
              data-testid={`badge-skill-${index}`}
            >
              {skill}
              <button
                onClick={() => handleRemoveSkill(skill)}
                data-testid={`button-remove-skill-${index}`}
                className="ml-1 hover-elevate active-elevate-2 rounded-full p-0.5"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}
