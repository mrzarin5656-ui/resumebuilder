import ThemeCustomizer from "../ThemeCustomizer";
import { useState } from "react";
import type { ColorTheme } from "@shared/schema";

export default function ThemeCustomizerExample() {
  const [theme, setTheme] = useState<ColorTheme>({
    accentColor: "#3b82f6",
    headerStyle: "line",
  });

  const handleThemeChange = (newTheme: ColorTheme) => {
    setTheme(newTheme);
    console.log("Theme updated:", newTheme);
  };

  return <ThemeCustomizer theme={theme} onThemeChange={handleThemeChange} />;
}
