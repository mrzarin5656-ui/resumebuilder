import ResumePreview from "../ResumePreview";
import type { ResumeData } from "@shared/schema";

export default function ResumePreviewExample() {
  const sampleData: ResumeData = {
    fullName: "Jane Smith",
    jobTitle: "Senior Software Engineer",
    email: "jane.smith@email.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA",
    summary:
      "Results-driven software engineer with 8+ years of experience building scalable web applications. Passionate about clean code, user experience, and mentoring junior developers.",
    skills: [
      "JavaScript",
      "TypeScript",
      "React",
      "Node.js",
      "Python",
      "SQL",
      "AWS",
      "Docker",
    ],
    education: [
      {
        id: "1",
        institution: "Stanford University",
        degree: "Master of Science in Computer Science",
        startDate: "Sep 2012",
        endDate: "Jun 2014",
        description: "Focus on distributed systems and machine learning",
      },
    ],
    experience: [
      {
        id: "1",
        company: "Tech Corp",
        position: "Senior Software Engineer",
        startDate: "Jan 2020",
        endDate: "Present",
        description:
          "Lead a team of 5 engineers in developing microservices architecture. Improved system performance by 40% and reduced deployment time by 60%.",
      },
      {
        id: "2",
        company: "StartupXYZ",
        position: "Full Stack Developer",
        startDate: "Jun 2016",
        endDate: "Dec 2019",
        description:
          "Built and maintained customer-facing web applications serving 100K+ users. Implemented CI/CD pipeline reducing bugs by 30%.",
      },
    ],
    theme: {
      accentColor: "#6366f1",
      headerStyle: "line",
    },
  };

  return <ResumePreview data={sampleData} />;
}
