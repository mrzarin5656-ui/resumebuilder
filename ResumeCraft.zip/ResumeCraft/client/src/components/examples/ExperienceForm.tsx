import ExperienceForm from "../ExperienceForm";
import { useState } from "react";
import type { Experience } from "@shared/schema";

export default function ExperienceFormExample() {
  const [experience, setExperience] = useState<Experience[]>([]);

  const handleExperienceChange = (newExperience: Experience[]) => {
    setExperience(newExperience);
    console.log("Experience updated:", newExperience);
  };

  return (
    <ExperienceForm
      experience={experience}
      onExperienceChange={handleExperienceChange}
    />
  );
}
