import SkillsForm from "../SkillsForm";
import { useState } from "react";

export default function SkillsFormExample() {
  const [skills, setSkills] = useState<string[]>([]);

  const handleSkillsChange = (newSkills: string[]) => {
    setSkills(newSkills);
    console.log("Skills updated:", newSkills);
  };

  return <SkillsForm skills={skills} onSkillsChange={handleSkillsChange} />;
}
