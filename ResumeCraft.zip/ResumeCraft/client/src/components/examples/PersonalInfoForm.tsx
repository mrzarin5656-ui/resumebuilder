import PersonalInfoForm from "../PersonalInfoForm";
import { useState } from "react";

export default function PersonalInfoFormExample() {
  const [formData, setFormData] = useState({
    fullName: "",
    jobTitle: "",
    email: "",
    phone: "",
    location: "",
    summary: "",
  });

  const handleFieldChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    console.log(`${field} changed to: ${value}`);
  };

  return (
    <PersonalInfoForm
      fullName={formData.fullName}
      jobTitle={formData.jobTitle}
      email={formData.email}
      phone={formData.phone}
      location={formData.location}
      summary={formData.summary}
      onFieldChange={handleFieldChange}
    />
  );
}
