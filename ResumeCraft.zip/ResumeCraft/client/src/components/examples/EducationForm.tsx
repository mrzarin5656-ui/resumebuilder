import EducationForm from "../EducationForm";
import { useState } from "react";
import type { Education } from "@shared/schema";

export default function EducationFormExample() {
  const [education, setEducation] = useState<Education[]>([]);

  const handleEducationChange = (newEducation: Education[]) => {
    setEducation(newEducation);
    console.log("Education updated:", newEducation);
  };

  return (
    <EducationForm
      education={education}
      onEducationChange={handleEducationChange}
    />
  );
}
