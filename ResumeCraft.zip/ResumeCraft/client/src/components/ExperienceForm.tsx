import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plus, Trash2 } from "lucide-react";
import type { Experience } from "@shared/schema";

interface ExperienceFormProps {
  experience: Experience[];
  onExperienceChange: (experience: Experience[]) => void;
}

export default function ExperienceForm({
  experience,
  onExperienceChange,
}: ExperienceFormProps) {
  const handleAddExperience = () => {
    const newExperience: Experience = {
      id: Date.now().toString(),
      company: "",
      position: "",
      startDate: "",
      endDate: "",
      description: "",
    };
    onExperienceChange([...experience, newExperience]);
  };

  const handleRemoveExperience = (id: string) => {
    onExperienceChange(experience.filter((exp) => exp.id !== id));
  };

  const handleFieldChange = (id: string, field: keyof Experience, value: string) => {
    onExperienceChange(
      experience.map((exp) =>
        exp.id === id ? { ...exp, [field]: value } : exp
      )
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Work Experience</h2>
        <Button
          type="button"
          variant="outline"
          size="sm"
          data-testid="button-add-experience"
          onClick={handleAddExperience}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Experience
        </Button>
      </div>

      <div className="space-y-4">
        {experience.map((exp, index) => (
          <Card key={exp.id} className="p-6" data-testid={`card-experience-${index}`}>
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 space-y-4">
                  <div>
                    <Label htmlFor={`company-${exp.id}`} className="text-sm font-medium">
                      Company
                    </Label>
                    <Input
                      id={`company-${exp.id}`}
                      data-testid={`input-company-${index}`}
                      placeholder="Company Name"
                      value={exp.company}
                      onChange={(e) =>
                        handleFieldChange(exp.id, "company", e.target.value)
                      }
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor={`position-${exp.id}`} className="text-sm font-medium">
                      Position
                    </Label>
                    <Input
                      id={`position-${exp.id}`}
                      data-testid={`input-position-${index}`}
                      placeholder="Senior Software Engineer"
                      value={exp.position}
                      onChange={(e) =>
                        handleFieldChange(exp.id, "position", e.target.value)
                      }
                      className="mt-1"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor={`startDate-${exp.id}`} className="text-sm font-medium">
                        Start Date
                      </Label>
                      <Input
                        id={`startDate-${exp.id}`}
                        data-testid={`input-exp-start-date-${index}`}
                        placeholder="Jan 2020"
                        value={exp.startDate}
                        onChange={(e) =>
                          handleFieldChange(exp.id, "startDate", e.target.value)
                        }
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor={`endDate-${exp.id}`} className="text-sm font-medium">
                        End Date
                      </Label>
                      <Input
                        id={`endDate-${exp.id}`}
                        data-testid={`input-exp-end-date-${index}`}
                        placeholder="Present"
                        value={exp.endDate}
                        onChange={(e) =>
                          handleFieldChange(exp.id, "endDate", e.target.value)
                        }
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor={`description-${exp.id}`} className="text-sm font-medium">
                      Description
                    </Label>
                    <Textarea
                      id={`description-${exp.id}`}
                      data-testid={`input-exp-description-${index}`}
                      placeholder="Key responsibilities and achievements..."
                      value={exp.description}
                      onChange={(e) =>
                        handleFieldChange(exp.id, "description", e.target.value)
                      }
                      rows={3}
                      className="mt-1 resize-none"
                    />
                  </div>
                </div>

                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  data-testid={`button-remove-experience-${index}`}
                  onClick={() => handleRemoveExperience(exp.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}

        {experience.length === 0 && (
          <button
            type="button"
            onClick={handleAddExperience}
            data-testid="button-add-first-experience"
            className="w-full border-2 border-dashed border-border rounded-md p-8 text-center hover-elevate active-elevate-2"
          >
            <Plus className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
            <p className="text-sm font-medium text-muted-foreground">
              Add your first work experience
            </p>
          </button>
        )}
      </div>
    </div>
  );
}
