import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface PersonalInfoFormProps {
  fullName: string;
  jobTitle: string;
  email: string;
  phone: string;
  location: string;
  summary: string;
  onFieldChange: (field: string, value: string) => void;
}

export default function PersonalInfoForm({
  fullName,
  jobTitle,
  email,
  phone,
  location,
  summary,
  onFieldChange,
}: PersonalInfoFormProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-4">Personal Information</h2>
        <div className="space-y-4">
          <div>
            <Label htmlFor="fullName" className="text-sm font-medium">
              Full Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="fullName"
              data-testid="input-fullname"
              placeholder="John Doe"
              value={fullName}
              onChange={(e) => onFieldChange("fullName", e.target.value)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="jobTitle" className="text-sm font-medium">
              Job Title <span className="text-destructive">*</span>
            </Label>
            <Input
              id="jobTitle"
              data-testid="input-jobtitle"
              placeholder="Software Engineer"
              value={jobTitle}
              onChange={(e) => onFieldChange("jobTitle", e.target.value)}
              className="mt-1"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="email" className="text-sm font-medium">
                Email <span className="text-destructive">*</span>
              </Label>
              <Input
                id="email"
                data-testid="input-email"
                type="email"
                placeholder="john@example.com"
                value={email}
                onChange={(e) => onFieldChange("email", e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="phone" className="text-sm font-medium">
                Phone
              </Label>
              <Input
                id="phone"
                data-testid="input-phone"
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={phone}
                onChange={(e) => onFieldChange("phone", e.target.value)}
                className="mt-1"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="location" className="text-sm font-medium">
              Location
            </Label>
            <Input
              id="location"
              data-testid="input-location"
              placeholder="San Francisco, CA"
              value={location}
              onChange={(e) => onFieldChange("location", e.target.value)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="summary" className="text-sm font-medium">
              Professional Summary
            </Label>
            <Textarea
              id="summary"
              data-testid="input-summary"
              placeholder="A brief overview of your professional background and career objectives..."
              value={summary}
              onChange={(e) => onFieldChange("summary", e.target.value)}
              rows={4}
              className="mt-1 resize-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
