import type { ResumeData } from "@shared/schema";

interface ResumePreviewProps {
  data: ResumeData;
}

export default function ResumePreview({ data }: ResumePreviewProps) {
  const hasContent =
    data.fullName ||
    data.jobTitle ||
    data.email ||
    data.phone ||
    data.location ||
    data.summary ||
    data.skills.length > 0 ||
    data.education.length > 0 ||
    data.experience.length > 0;

  if (!hasContent) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground">
        <p className="text-center">
          Start filling out the form to see your resume preview
        </p>
      </div>
    );
  }

  const accentColor = data.theme.accentColor;
  const headerStyle = data.theme.headerStyle;

  const getSectionHeaderClasses = () => {
    if (headerStyle === "filled") {
      return "text-lg font-semibold uppercase tracking-wide mb-2 px-3 py-1 text-white";
    }
    return "text-lg font-semibold uppercase tracking-wide mb-2 pb-1";
  };

  const getSectionBorderClasses = () => {
    if (headerStyle === "line") {
      return "border-b-2";
    }
    if (headerStyle === "bold") {
      return "border-b";
    }
    return "";
  };

  return (
    <div
      id="resume-preview"
      className="bg-white text-gray-900 p-12 shadow-lg h-full overflow-auto"
      data-testid="resume-preview"
    >
      <div className="space-y-6">
        {(data.fullName || data.jobTitle) && (
          <div
            className={`pb-4 ${headerStyle === "filled" ? "px-4 py-3 -mx-4 text-white" : headerStyle === "line" ? "border-b-2" : "border-b"}`}
            style={
              headerStyle === "filled"
                ? { backgroundColor: accentColor }
                : headerStyle === "line"
                ? { borderColor: accentColor }
                : { borderColor: "#1f2937" }
            }
          >
            {data.fullName && (
              <h1
                className="text-4xl font-bold font-serif mb-2"
                data-testid="preview-name"
                style={headerStyle !== "filled" ? { color: accentColor } : {}}
              >
                {data.fullName}
              </h1>
            )}
            {data.jobTitle && (
              <p
                className={`text-xl ${headerStyle === "filled" ? "text-white opacity-90" : "text-gray-600"}`}
                data-testid="preview-jobtitle"
              >
                {data.jobTitle}
              </p>
            )}
          </div>
        )}

        {(data.email || data.phone || data.location) && (
          <div className="flex flex-wrap gap-2 text-sm" data-testid="preview-contact">
            {data.email && <span>{data.email}</span>}
            {data.email && (data.phone || data.location) && (
              <span className="text-gray-400">•</span>
            )}
            {data.phone && <span>{data.phone}</span>}
            {data.phone && data.location && <span className="text-gray-400">•</span>}
            {data.location && <span>{data.location}</span>}
          </div>
        )}

        {data.summary && (
          <div>
            <h2
              className={getSectionHeaderClasses() + " " + getSectionBorderClasses()}
              style={
                headerStyle === "filled"
                  ? { backgroundColor: accentColor }
                  : headerStyle === "line"
                  ? { borderColor: accentColor, color: accentColor }
                  : { color: accentColor }
              }
            >
              Professional Summary
            </h2>
            <p className="text-sm leading-relaxed text-gray-700" data-testid="preview-summary">
              {data.summary}
            </p>
          </div>
        )}

        {data.skills.length > 0 && (
          <div>
            <h2
              className={getSectionHeaderClasses() + " " + getSectionBorderClasses()}
              style={
                headerStyle === "filled"
                  ? { backgroundColor: accentColor }
                  : headerStyle === "line"
                  ? { borderColor: accentColor, color: accentColor }
                  : { color: accentColor }
              }
            >
              Skills
            </h2>
            <div className="text-sm leading-relaxed text-gray-700" data-testid="preview-skills">
              {data.skills.join(" • ")}
            </div>
          </div>
        )}

        {data.experience.length > 0 && (
          <div>
            <h2
              className={getSectionHeaderClasses() + " " + getSectionBorderClasses()}
              style={
                headerStyle === "filled"
                  ? { backgroundColor: accentColor }
                  : headerStyle === "line"
                  ? { borderColor: accentColor, color: accentColor }
                  : { color: accentColor }
              }
            >
              Work Experience
            </h2>
            <div className="space-y-4" data-testid="preview-experience">
              {data.experience.map((exp, index) => (
                <div key={exp.id} className="space-y-1">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      {exp.position && (
                        <h3 className="font-semibold text-sm">{exp.position}</h3>
                      )}
                      {exp.company && (
                        <p className="text-sm text-gray-600">{exp.company}</p>
                      )}
                    </div>
                    {(exp.startDate || exp.endDate) && (
                      <p className="text-sm text-gray-500">
                        {exp.startDate}
                        {exp.startDate && exp.endDate && " - "}
                        {exp.endDate}
                      </p>
                    )}
                  </div>
                  {exp.description && (
                    <p className="text-sm leading-relaxed text-gray-700 whitespace-pre-wrap">
                      {exp.description}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {data.education.length > 0 && (
          <div>
            <h2
              className={getSectionHeaderClasses() + " " + getSectionBorderClasses()}
              style={
                headerStyle === "filled"
                  ? { backgroundColor: accentColor }
                  : headerStyle === "line"
                  ? { borderColor: accentColor, color: accentColor }
                  : { color: accentColor }
              }
            >
              Education
            </h2>
            <div className="space-y-4" data-testid="preview-education">
              {data.education.map((edu, index) => (
                <div key={edu.id} className="space-y-1">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      {edu.degree && (
                        <h3 className="font-semibold text-sm">{edu.degree}</h3>
                      )}
                      {edu.institution && (
                        <p className="text-sm text-gray-600">{edu.institution}</p>
                      )}
                    </div>
                    {(edu.startDate || edu.endDate) && (
                      <p className="text-sm text-gray-500">
                        {edu.startDate}
                        {edu.startDate && edu.endDate && " - "}
                        {edu.endDate}
                      </p>
                    )}
                  </div>
                  {edu.description && (
                    <p className="text-sm leading-relaxed text-gray-700 whitespace-pre-wrap">
                      {edu.description}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
