import { z } from "zod";

export const educationSchema = z.object({
  id: z.string(),
  institution: z.string(),
  degree: z.string(),
  startDate: z.string(),
  endDate: z.string(),
  description: z.string(),
});

export const experienceSchema = z.object({
  id: z.string(),
  company: z.string(),
  position: z.string(),
  startDate: z.string(),
  endDate: z.string(),
  description: z.string(),
});

export const colorThemeSchema = z.object({
  accentColor: z.string(),
  headerStyle: z.enum(["bold", "line", "filled"]),
});

export const resumeDataSchema = z.object({
  fullName: z.string(),
  jobTitle: z.string(),
  email: z.string(),
  phone: z.string(),
  location: z.string(),
  summary: z.string(),
  skills: z.array(z.string()),
  education: z.array(educationSchema),
  experience: z.array(experienceSchema),
  theme: colorThemeSchema,
});

export type Education = z.infer<typeof educationSchema>;
export type Experience = z.infer<typeof experienceSchema>;
export type ColorTheme = z.infer<typeof colorThemeSchema>;
export type ResumeData = z.infer<typeof resumeDataSchema>;
